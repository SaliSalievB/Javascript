function sendmsg(){
    // your code goes here
    // get text from text input
    let chatmsg;
    

     document.getElementById("chatmsg").value;
    
    // create P with: <p><b>Me:</b> MSG from textbox</p>

    
        let newEl = document.createElement("p");
        newEl.innerHTML = " <b> Me: </b>";
        document.body.append(newEl);

        div.append(p)
 
    // append it to chatbox
    // clear text input
    
    const btn = document.getElementById('sendmsg');

    sendmsg.addEventListener('click', function handleClick(event) {
 
  event.preventDefault();

  const firstNameInput = document.getElementById('first_name');

  console.log(firstNameInput.value);

  firstNameInput.value = '';
});
}