window.onload = function () {
  
    var Seconds = 00; 
    var Tens = 00; 
    var appendTens = document.getElementById("Tens")
    var appendSeconds = document.getElementById("Seconds")
    var buttonStart = document.getElementById('Start');
    var buttonStop = document.getElementById('Stop');
    var buttonReset = document.getElementById('Reset');
    var Interval ;
  
    buttonStart.onclick = function() {
      
      clearInterval(Interval);
       Interval = setInterval(startTimer, 10);
    }
    
      buttonStop.onclick = function() {
         clearInterval(Interval);
    }
    
  
    buttonReset.onclick = function() {
       clearInterval(Interval);
      Tens = "00";
        Seconds = "00";
      appendTens.innerHTML = Tens;
        appendSeconds.innerHTML = Seconds;
    }
    
     
    
    function startTimer () {
      Tens++; 
      
      if(Tens <= 9){
        appendTens.innerHTML = "0" + Tens;
      }
      
      if (Tens > 9){
        appendTens.innerHTML = Tens;
        
      } 
      
      if (Tens > 99) {
        console.log("seconds");
        Seconds++;
        appendSeconds.innerHTML = "0" + Seconds;
        Tens = 0;
        appendTens.innerHTML = "0" + 0;
      }
      
      if (Seconds > 9){
        appendSeconds.innerHTML = Seconds;
      }
    
    }
    
  
  }